import java.util.ArrayList;
import java.util.List;

interface Subject {
    void registerObserver(Observer observer);
    void unregisterObserver(Observer observer);
    void notifyObservers(float price);
}

class Stock implements Subject {
    private String symbol;
    private float price;
    private List<Observer> investors;

    public Stock(String symbol, float price) {
        this.symbol = symbol;
        this.price = price;
        this.investors = new ArrayList<>();
    }

    public void setPrice(float price) {
        this.price = price;
        notifyObservers(price);
    }

    @Override
    public void registerObserver(Observer observer) {
        investors.add(observer);
    }

    @Override
    public void unregisterObserver(Observer observer) {
        investors.remove(observer);
    }

    @Override
    public void notifyObservers(float price) {
        for (Observer investor : investors) {
            investor.update(symbol, price);
        }
    }
}

interface Observer {
    void update(String symbol, float price);
}
class Investor implements Observer {
    private String name;

    public Investor(String name) {
        this.name = name;
    }

    @Override
    public void update(String symbol, float price) {
        System.out.println(name + ": " + symbol + " price updated to " + price);
    }
}
interface Iterator {
    boolean hasNext();
    Song next();
}
interface Playlist {
    Iterator createIterator();
    void addSong(Song song);
}
class SongIterator implements Iterator {
    private List<Song> songs;
    private int position = 0;

    public SongIterator(List<Song> songs) {
        this.songs = songs;
    }

    @Override
    public boolean hasNext() {
        return position < songs.size();
    }

    @Override
    public Song next() {
        return songs.get(position++);
    }
}
class PlaylistImpl implements Playlist {
    private List<Song> songs;

    public PlaylistImpl() {
        this.songs = new ArrayList<>();
    }

    @Override
    public Iterator createIterator() {
        return new SongIterator(songs);
    }

    @Override
    public void addSong(Song song) {
        songs.add(song);
    }
}
class Song {
    private String title;
    private String artist;

    public Song(String title, String artist) {
        this.title = title;
        this.artist = artist;
    }
    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }
}

public class Main {
    public static void main(String[] args) {
        Stock appleStock = new Stock("AAPL", 150.0f);
        Investor investor1 = new Investor("John");
        Investor investor2 = new Investor("Alice");

        appleStock.registerObserver(investor1);
        appleStock.registerObserver(investor2);

        appleStock.setPrice(160.0f);

        appleStock.unregisterObserver(investor1);
        appleStock.setPrice(170.0f);

        Playlist playlist = new PlaylistImpl();
        playlist.addSong(new Song("Song 1", "Artist 1"));
        playlist.addSong(new Song("Song 2", "Artist 2"));
        playlist.addSong(new Song("Song 3", "Artist 3"));

        Iterator iterator = playlist.createIterator();
        while (iterator.hasNext()) {
            Song song = iterator.next();
            System.out.println("Playing: " + song.getTitle() + " by " + song.getArtist());
        }
    }
}
